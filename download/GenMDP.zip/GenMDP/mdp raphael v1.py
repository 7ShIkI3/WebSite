import string
import random
from random import randint, choice
import os
import re
from tkinter import * 
import tkinter as tk
import webbrowser

def gen_mdp():
    mdp_max=15
    lettres = string.ascii_letters
    chiffres = string.digits
    ponctuation = string.punctuation
    
    code = lettres+chiffres+ponctuation
    
    mdp = random.sample(code,mdp_max)
    mdp_final = "".join(mdp)
    
    password.delete(0, END)
    password.insert(0, mdp_final)
    
    try:
        f = open("Mdo_Historique\mdp.txt","a") #vérifie l'existance du fichier
        f.write("\n",)
        f.write(mdp_final)
        f.close()
    except:
        os.mkdir('Mdo_Historique')
        f = open("Mdo_Historique\mdp.txt","a") #mode creation de fichier
        f.write(mdp_final)
        f.close()


def regexverif():
    checkedValue=None
    p = re.compile('^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9])(?=.*?[#?!@$%^&;|_~&%§*"-`+=]()).{8,}')
    check.delete(0, END)
    checkedValue = p.match(password.get())
    if checkedValue == None :
        check.insert(0, "Invalid Password !")
    else :
        #check.insert(0, checkedValue.group())
        check.insert(0, "Good Password")


def kaspersky():
    webbrowser.open_new("https://password.kaspersky.com/")


fenetre = tk.Tk() #Création d'une fenêtre avec la classe Tk abreviation de tkinter:
fenetre.title("Generateur de mots de passes") #nom de la fenetre
fenetre.iconbitmap("image\mdpimg.ico") #logo
fenetre.geometry("800x500") #taille de la fenetre
fenetre.maxsize(1200,900) #taille minimal de la fenetre
fenetre.minsize(1000,800) #taille maximal de la fenetre
fenetre.config(bg = "#ADD8E6") #couleur de la fenetre


#ajoute la frame
frame = Frame(fenetre, bg='#ADD8E6') 
bis_frame = Frame(frame, bg='#ADD8E6')
right_frame = Frame(frame, bg='#ADD8E6')


#ajoute un texte et un bar textuelle
tailliste = Label (bis_frame ,text = "Mot de Passe" , font=("Courrier",28), bg='#ADD8E6', fg='white')
tailliste.pack()


#champ (input)
password = Entry(bis_frame, font=("Courrier",28), bg='#ADD8E6', fg='white')
password.pack()


#gen
gen = Button(bis_frame,text="Générer", font=("Courrier",28), bg='#ADD8E6', fg='white', command=gen_mdp)
gen.pack(fill=X)


#texte
Verification = Label (right_frame ,text = "Vérification" , font=("Courrier",28), bg='#ADD8E6', fg='white')
Verification.pack()


#champ (input) qui affiche si le mots de passe et bien conforme au exigence
check = Entry(right_frame, font=("Courrier",28), bg='#ADD8E6', fg='white')
check.pack()


#verif
verif = Button(right_frame,text="Vérification", font=("Courrier",28), bg='#ADD8E6', fg='white',command=regexverif)
verif.pack(fill=X)


#bouton pour verifier sur kaspersky
kasperskybouton = Button(frame, text="kaspersky" ,font=("Courrier",30), bg='white', fg='#ADD8E6',width=18, command=kaspersky)
kasperskybouton.grid(row=1, column=1,sticky=W)

#affiche 
frame.pack(expand=YES)
bis_frame.grid(row=0, column=1, sticky=W)
right_frame.grid(row=0, column=2, sticky=W)

fenetre.mainloop() # Affichage de la fenêtre créée 
